function Shop(){
    return(
        <>
        <h2>Welcome to Shop Page</h2>
        </>
    )
}

export default Shop;