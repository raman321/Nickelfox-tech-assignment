function Contact(){
    return(
        <>
        <h2>Welcome to Contact Page</h2>
        </>
    )
}

export default Contact;