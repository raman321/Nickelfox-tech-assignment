import React from 'react';
import Navbar from '../src/components/Navbar'
import Slider from '../src/components/slider';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import './App.css';
import Home from '../src/components/pages/Home'
import Shop from '../src/components/pages/Shop'
import About from '../src/components/pages/About'
import Contact from '../src/components/pages/Contact'

function App() {
  return (
    <>
    <Router>
    <Navbar />
    <Slider />
    <Switch>
      <Route path = '/' exact component = {Home}/>
      <Route path = '/Shop' exact component = {Shop}/>
      <Route path = '/About' exact component = {About}/>
      <Route path = '/Contact' exact component = {Contact}/>
    </Switch>
    </Router>
      
    </>
  );
}

export default App;
