function About(){
    return(
        <>
        <h2>Welcome to About Page</h2>
        </>
    )
}

export default About;