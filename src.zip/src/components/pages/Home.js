import '../../App.css'
function Home(){
    return(
        <>
        <h2>Welcome to Home Page</h2>
        </>
    )
}

export default Home;